# Nisheet Agrawal - Portfolio Website

A modern, responsive portfolio website for Nisheet Agrawal, a Data Scientist and Business Analyst.

## Features

- Responsive design that works on all devices
- Modern UI with smooth animations
- Sections for showcasing skills, experience, projects, and education
- Contact form for potential employers or clients
- Interactive navigation with smooth scrolling

## Technologies Used

- HTML5
- CSS3 (with CSS variables and flexbox/grid layouts)
- JavaScript (vanilla)
- Font Awesome for icons
- Google Fonts (Poppins)

## How to Use

1. Clone or download this repository
2. Open `index.html` in your web browser
3. To make changes:
   - Edit `index.html` to update content
   - Modify `css/styles.css` to change styling
   - Update `js/script.js` to adjust functionality

## Customization

### Adding a Profile Picture

To add your profile picture:
1. Add your image to the `images` folder
2. In `index.html`, find the `.profile-img-placeholder` div in the hero section
3. Replace the placeholder with your image:
   ```html
   <div class="hero-image">
       <img src="images/your-photo.jpg" alt="Nisheet Agrawal" class="profile-img">
   </div>
   ```
4. In `css/styles.css`, add styling for the profile image:
   ```css
   .profile-img {
       width: 300px;
       height: 300px;
       border-radius: 50%;
       object-fit: cover;
       box-shadow: var(--box-shadow);
       border: 5px solid white;
   }
   ```

### Changing Colors

The website uses CSS variables for colors. To change the color scheme, edit the `:root` section in `css/styles.css`:

```css
:root {
    --primary-color: #your-primary-color;
    --secondary-color: #your-secondary-color;
    --dark-color: #your-dark-color;
    --light-color: #your-light-color;
    --text-color: #your-text-color;
    /* other variables */
}
```

## Contact Form Integration

The contact form currently shows an alert on submission. To make it functional:

1. Set up a backend service (e.g., PHP, Node.js) to handle form submissions
2. Update the form submission code in `js/script.js` to send data to your backend
3. Alternatively, use a form service like Formspree or Netlify Forms

## License

This project is available for personal use.

## Credits

- Icons: [Font Awesome](https://fontawesome.com/)
- Fonts: [Google Fonts](https://fonts.google.com/) 